rm -rf ./jdewin_pre.ps1
echo "net user Administrator $1;" >> ./jdewin_pre.ps1
echo "net user Administrator;" >> ./jdewin_pre.ps1
echo "Enable-PSRemoting -Force;" >> ./jdewin_pre.ps1
echo "Set-NetFirewallProfile -Profile Private -Enabled False;" >> ./jdewin_pre.ps1
echo "New-NetFirewallRule -DisplayName 'JDE Inbound' -Profile @('Domain', 'Private', 'Public') -Direction Inbound -Action Allow -Protocol TCP -LocalPort @('3389', '14502', '5985', '445', '139', '8998');" >> ./jdewin_pre.ps1
echo "New-NetFirewallRule -DisplayName 'JDE Outbound' -Profile @('Domain', 'Private', 'Public') -Direction Outbound -Action Allow -Protocol TCP -RemotePort @all;" >> ./jdewin_pre.ps1
echo "Set-Service -Name msiscsi -StartupType Automatic;" >> ./jdewin_pre.ps1
echo "Start-Service msiscsi;" >> ./jdewin_pre.ps1
echo "New-IscsiTargetPortal -TargetPortalAddress $2;" >> ./jdewin_pre.ps1
echo "Connect-IscsiTarget -NodeAddress $3 -TargetPortalAddress $2 -IsPersistent \$True;" >> ./jdewin_pre.ps1
echo "Set-Disk 1 -IsOffline \$False;" >> ./jdewin_pre.ps1
echo "Initialize-Disk 1;" >> ./jdewin_pre.ps1
echo "New-Partition -DiskNumber 1 -AssignDriveLetter -UseMaximumSize;" >> ./jdewin_pre.ps1
echo "Format-Volume -DriveLetter D -FileSystem NTFS -NewFileSystemLabel JDEVol -Confirm:\$False" >> ./jdewin_pre.ps1
exit

