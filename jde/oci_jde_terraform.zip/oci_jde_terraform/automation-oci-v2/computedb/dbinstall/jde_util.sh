#!/bin/bash



remove_dir()
{
sudo rm -rf $1 | tee -a $2
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "ERROR!! Unable to delete directory" | tee -a $2
exit
fi

}

transfer_binaries()
{
ssh -i $key -o "StrictHostKeyChecking no" -o LogLevel=QUIET -tt opc@$1 "sudo mkdir -p $2;sudo chown -R opc:opc $2" | tee -a $5

if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "ERROR!! Unable to create REMOTE BINARY PATH" | tee -a $5
exit
fi

scp -i $key -o "StrictHostKeyChecking no" $3/$4 opc@$1:$2 | tee -a $5

if [[ ${PIPESTATUS[0]} -ne 0 ]]; then
	echo "ERROR!! Unable to move JDE payload to REMOTE BINARY PATH" | tee -a $5
	exit
else
	echo "Successfully moved JDE payload to REMOTE BINARY PATH" | tee -a $5
fi

}



extract_zip()
{
cd $1;unzip -o -q "$2" -d $1 | tee -a $3

if [[ ${PIPESTATUS[0]} -ne 0 ]]; then
	echo "ERROR!! Unzip of artifact failed" | tee -a $3
	exit
else
    echo "Unzip completed succesfully" | tee -a $3
fi

}

extract_tar()
{
cd $1;tar -zxvf $2 -C $3 --strip-components=1

if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "ERROR!! Unzip of artifact failed"
exit
fi

}

change_owner_oracle()
{
sudo chown -R oracle:oracle $1 | tee -a $2
}

change_file_permission()
{
sudo chmod -R 777 $1
if [[ $? -ne 0 ]]
then
echo "Error while changing permission"
exit
fi
}

create_remote_directory()
{
sudo mkdir -p $1 | tee -a $2
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "Error while creating directory"
exit
fi
}






find_oracle_group()
{
oracle_grp=$(ssh -i $key -o "StrictHostKeyChecking no" -tt opc@$1 "sudo id -Gn oracle")
if [[ $? -ne 0 ]]
then
echo "oracle user doesn't exist"
exit
fi
echo "$oracle_grp"
}


remove_oracledb()
{

echo "----Checking previous Oracle DB software installed------"

sudo su - oracle -c 'test -f $1/app/oracle/product/12.1.0/dbhome_1/deinstall/deinstall'

if [[ $? -eq 0 ]]; then

echo "----------------Deinstalling previous Oracle DB ------------------------"

sudo su - oracle -c "$1/app/oracle/product/$2/dbhome_1/deinstall/deinstall -silent -checkonly -tmpdir $1/jde_tf" | tee -a $3
sudo su - oracle -c "$1/app/oracle/product/$2/dbhome_1/deinstall/deinstall -silent -paramfile /$1/jde_tf/deinstall*/response*/*.rsp" | tee -a $3
sudo rm -rf /etc/oraInst.loc | tee -a $3
sudo rm -rf /opt/ORCLfmap | tee -a $3
sudo rm -rf /etc/oratab | tee -a $3

else
  echo "-----No Oracle database software is found. Starting a fresh Install---"
fi	


}


install_oracle12102_EE_SI()
{
echo "---------------Running Oracle Installer---------------------------------"
sudo su - oracle -c "$1/jde_tf/dbbinary/database/runInstaller -ignoreSysPrereqs -ignorePrereq -waitforcompletion -showProgress -silent -responseFile $1/jde_tf/dbinstall/templates/db$2.rsp" | tee -a $3
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "Oracle DB Installer Failed. Check logs"
exit
fi


echo "---------------------------Running root scripts-----------------------------------"
sudo $1/app/oracle/product/12.1.0/dbhome_1/root.sh | tee -a $3
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "Oracle DB Installer Failed while running root scripts. Check logs"
exit
fi



echo "----------------Running netca------------------------"
sudo su - oracle -c "$1/app/oracle/product/12.1.0/dbhome_1/bin/netca -silent -responseFile $1/jde_tf/dbinstall/templates/netca.rsp" | tee -a $3

if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "Creation of Listener Failed. Check logs"
exit
fi


#echo "-------------Running configToolAllCommands-------------------------"
#ssh -i $5 -o "StrictHostKeyChecking no" -tt opc@$1 "sudo su - oracle -c '$2/app/oracle/product/12.1.0/dbhome_1/cfgtoollogs/configToolAllCommands RESPONSE_FILE=/home/oracle/oracfg.rsp'" | tee -a $4

echo "---------------------------------Running DBCA--------------------------------------------"
sudo su - oracle -c "$1/app/oracle/product/12.1.0/dbhome_1/bin/dbca -silent -createDatabase -responseFile $1/jde_tf/dbinstall/templates/dbca.rsp" | tee -a $3
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
echo "Creation of Database  Failed. Check logs"
exit
fi

}


install_oracle1202_EE_SI()
{

echo "----------------Runing Oracle DB Installer-----------------------------"
sudo su - oracle -c "$1/jde_tf/dbbinary/database/runInstaller -ignoreSysPrereqs -ignorePrereq -waitforcompletion -showProgress -silent -responseFile $1/jde_tf/db$2.rsp" | tee -a $3
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
    echo "Oracle DB Installer Failed. Check logs"
    exit
fi

echo "---------------------------Running root scripts--------------------------------"

sudo $1/app/oracle/product/12.2.0/dbhome_1/root.sh | tee -a $3
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
    echo "Oracle DB Installer Failed when running root scripts. Check logs"
    exit
fi


echo "----------------Running executeConfigTools-----------------------------------"
sudo su - oracle -c "$1/jde_tf/dbbinary/database/runInstaller -executeConfigTools -waitforcompletion -showProgress -silent -responseFile $1/jde_tf/db$2.rsp" | tee -a $3
if [[ ${PIPESTATUS[0]} -ne 0 ]]
then
    echo "Oracle DB Installer Failed when running executeConfigTools. Check logs"
    exit
fi

}

remove_pswd()
{
 sudo su - oracle -c "sed -i 's/.*oracle.install.db.config.starterdb.password.ALL=.*/oracle.install.db.config.starterdb.password.ALL=/' $2/jde_tf/dbinstall/templates/db$3.rsp" | tee -a $4

if [ "$1" == "12.1.0" ]; then
sudo su - oracle -c "sed -i 's/.*PDBADMINPASSWORD=.*/PDBADMINPASSWORD=/' $2/jde_tf/dbinstall/templates/dbca.rsp" | tee -a $4
sudo su - oracle -c "sed -i 's/.*SYSTEMPASSWORD=.*/SYSTEMPASSWORD=/' $2/jde_tf/dbinstall/templates/dbca.rsp" | tee -a $4
sudo su - oracle -c "sed -i 's/.*SYSPASSWORD=.*/SYSPASSWORD=/' $2/jde_tf/dbinstall/templates/dbca.rsp" | tee -a $4
fi
 
}

prreq_db()
{

sudo su - oracle -c "echo \"export ORACLE_SID=orcl\" >> /home/oracle/.bash_profile"

sudo su - oracle -c "echo \"export ORACLE_BASE=$1/app/oracle\" >> /home/oracle/.bash_profile"

sudo su - oracle -c "echo \"export ORACLE_HOME=$1/app/oracle/product/$2/dbhome_1\" >> /home/oracle/.bash_profile"

sudo su - oracle -c "echo \"export LD_LIBRARY_PATH=$1/app/oracle/product/$2/dbhome_1/lib:/lib:/usr/lib;\" >> /home/oracle/.bash_profile"

sudo su - oracle -c "echo \"export PATH=$PATH:$HOME/bin:$1/app/oracle/product/$2/dbhome_1/bin\" >> /home/oracle/.bash_profile"

sudo su - oracle -c "source /home/oracle/.bash_profile"

sudo su - oracle -c "exit | sqlplus / as sysdba @$1/jde_tf/dbinstall/templates/prereqdb.sql" | tee -a $3

sudo su - oracle -c "echo \"JDEORCL = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = $4)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = jdeorcl) ))\" >> $1/app/oracle/product/$2/dbhome_1/network/admin/tnsnames.ora"

}




