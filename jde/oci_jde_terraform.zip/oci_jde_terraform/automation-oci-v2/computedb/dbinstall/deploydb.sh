#!/bin/bash

export ORACLE_VERSION=$1
export SYSADMIN_PSWD=$2
export MOUNT_FS=$3
export TEMPLATE=$MOUNT_FS/jde_tf/dbinstall/templates


. $MOUNT_FS/jde_tf/dbinstall/jde_util.sh

#Edit response files
DB_INSTALL_PATH="$MOUNT_FS/app"
var=$(echo "$DB_INSTALL_PATH" | sed 's/\//\\\//g')

### Trim leading whitespaces ###
SYSADMIN_PSWD="${SYSADMIN_PSWD##*( )}"
### trim trailing whitespaces  ##
SYSADMIN_PSWD="${SYSADMIN_PSWD%%*( )}"
export SYSADMIN_PSWD



if [ "$ORACLE_VERSION" == "12.1.0" ]; then
        RSP=1210
        ORIG_RSP="db1210_orig.rsp"
        DB_INSTALL_BINARY_NAME="linuxamd64_12102_database*"
        rm -rf $TEMPLATE/dbca.rsp
        cp $TEMPLATE/dbca_orig.rsp $TEMPLATE/dbca.rsp
        sed -i "s/TF_DB_ADMIN_PSWD/$SYSADMIN_PSWD/g" $TEMPLATE/dbca.rsp

elif [ "$ORACLE_VERSION" == "12.2.0" ]; then
        RSP=1220
        ORIG_RSP="db1220_orig.rsp"
        DB_INSTALL_BINARY_NAME="linuxamd64_12102_database*"

else
        echo "Invalid Oracle DB version. Supported versions are 12.1.0 and 12.2.0"
        exit
fi



rm -rf $TEMPLATE/db$RSP.rsp
cp $TEMPLATE/$ORIG_RSP $TEMPLATE/db$RSP.rsp
sed -i "s/dbpath/$var/g" $TEMPLATE/db$RSP.rsp
sed -i "s/TF_DB_ADMIN_PSWD/$SYSADMIN_PSWD/g" ./templates/db$RSP.rsp                                                                                                          

host=${hostname}

sed -i "s/TF_DB_host/$host/g" $TEMPLATE/db$RSP.rsp
export LOGFILE=/tmp/dbprovisioning.log
rm -rf /tmp/$LOGFILE
echo "--Creating Remote directory --" | tee -a $LOGFILE
        create_remote_directory $MOUNT_FS/app $LOGFILE
        change_file_permission $MOUNT_FS/jde_tf $LOGFILE

        
echo "------------------Unzip DB Installer-----------------------" | tee -a $LOGFILE
	change_file_permission $MOUNT_FS/jde_tf/dbbinary $LOGFILE
        rm -rf $MOUNT_FS/jde_tf/dbbinary/database 
        extract_zip $MOUNT_FS/jde_tf/dbbinary $DB_INSTALL_BINARY_NAME $LOGFILE

    
echo "Installing Oracle $ORACLE_VERSION Enterprise Edition DB Server with Single Instance " | tee -a $LOGFILE
        remove_oracledb $MOUNT_FS $ORACLE_VERSION $LOGFILE
	remove_dir $MOUNT_FS/app $LOGFILE
        create_remote_directory $MOUNT_FS/app/oraInventory $LOGFILE
	change_owner_oracle $MOUNT_FS/app $LOGFILE

	
echo "--------Creating oraInst.loc on remote machine-----------" | tee -a $LOGFILE
        sudo su -c 'rm -rf /etc/oraInst.loc' | tee -a $LOGFILE
        if [ $? -eq 0 ] 
        then
  		sudo su -c "echo \"inventory_loc=$MOUNT_FS/app/oraInventory\" >> /etc/oraInst.loc"| tee -a $LOGFILE

   		sudo su -c "echo \"inst_group=oinstall\" >> /etc/oraInst.loc" | tee -a $LOGFILE
        fi
   
        if [ "$ORACLE_VERSION" == "12.2.0" ]; then
		install_oracle1202_EE_SI $MOUNT_FS $RSP $LOGFILE


	elif [ "$ORACLE_VERSION" == "12.1.0" ]; then
		install_oracle12102_EE_SI $MOUNT_FS $RSP $LOGFILE

	else
		echo "Invalid Oracle DB version"
		exit
	fi			


echo "-----------------------------Running pre requisite on Oracle DB---------------------------------" | tee -a $LOGFILE

	   change_owner_oracle $TEMPLATE/prereqdb.sql $LOGFILE
	   change_file_permission $TEMPLATE/prereqdb.sql | tee -a $LOGFILE
	   prreq_db $MOUNT_FS $ORACLE_VERSION $LOGFILE $host

echo "-----------------------------Removing passwords from response files---------------------------------"
	   remove_pswd $ORACLE_VERSION $MOUNT_FS $RSP $LOGFILE
exit
