spool /home/oracle/prereqdb.log
alter system set encrypt_new_tablespaces=ddl scope=both;
ALTER PROFILE default LIMIT PASSWORD_VERIFY_FUNCTION NULL;
alter profile DEFAULT limit PASSWORD_REUSE_TIME UNLIMITED;
alter profile DEFAULT limit PASSWORD_REUSE_MAX UNLIMITED;
alter database flashback off;
alter system set db_domain='' scope=spfile sid='*';
alter system set processes=1500 scope=spfile;
alter system set filesystemio_options=setall scope=spfile;
shutdown immediate;
startup mount exclusive;
alter database noarchivelog;
alter database open;
alter pluggable database JDEORCL open;
spool off;
